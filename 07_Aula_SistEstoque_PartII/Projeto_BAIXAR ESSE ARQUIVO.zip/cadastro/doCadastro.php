<?php
    //0)Verificando Session
	required('../login/verificador.php');
	VerificarLogin();

	//1) Conexao
	include('../conexao/conexao.php'); 

	//2) Recebendo os valores
	$nome = $_POST['nome'];
	$descricao = $_POST['descricao'];
	$area = $_POST['area'];
	$preco = $_POST['preco'];
	$moeda = $_POST['moeda'];
	$pais = $_POST['pais'];

	// 3) Imagem
	$arqTemp = ['foto']['tmp_name'];
	$arqNome = ['foto']['name'];

	// 4) Destino da imagem
	$destino  = 'C:/wamp64/www/imagens/'.$arqNome;

	//5) Movendo arquivo para o server
	if(@move_uploaded_file($arqTemp,$destino))
	{	
		//6) Query de insert
		$sql = "INSERT INTO produto(NOME,DESCRICAO,ID_AREA,PRECO_UNI,MOEDA,PAIS_ORIGEM,IMAGEM) VALUES 
		   ('$nome','$descricao',$area,$preco,'$moeda','$pais','$destino')";

		//7) Executar a Query
		$result = mysqli_query($con,$sql); 
		if(!$result)
		{
			echo "Erro ao cadastrar produto!!! Seu OTÁRIO!!!!";
			echo "<br>";
			echo $sql;
		}	

	}
	else
	{
		echo "Erro ao salvar o arquivo!!!";
		echo "<br>";
		echo "Caminho: <h4>$destino</h4>";
	}


?>