<?php
	//1) Incluindo o arquivo de verificação
	include '../login/verificador.php';

	//2) Chamando a função de verificar login
	VerificarLogin();

	//3) Conexao com DB
	require('../conexao/conexao.php');

	//4) Selecionand os itens
	$query = 'SELECT * FROM produtos';
	$produtos = mysqli_query($con,$query);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Listinha</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container mt-4">

	<!-- Substituindo jumbotron -->
	<div class="p-4 mb-4 bg-light rounded">
		<h1>Listagem de Produtos</h1>
		<p>Produtos fofos!</p>
		<p>Bem-vindo: <?php echo $_SESSION['login'] ?></p>
	</div>

	<!-- Navegação -->
	<ul class="nav nav-tabs mb-3">
		<li class="nav-item">
			<a class="nav-link" href="../Cadastro/cadastro.php">
				Cadastrar Produto
			</a> 
		</li>
		<li class="nav-item">
			<a class="nav-link active" href="#">
				Lista Produtos
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">
				Usuários
			</a>
		</li>
	</ul>

	<!-- Tabela -->
	<table class="table table-striped">
		<thead>
			<tr>
				<th>Nome</th>
				<th>Descrição</th>
				<th>Área</th>
				<th>Preço</th>
				<th>Moeda</th>
				<th>País</th>
				<th>Imagem</th>
				<th>Editar</th>
				<th>Visualizar</th>
			</tr>
		</thead>

		<?php
			// Percorrendo linha a linha
while ($linha = mysqli_fetch_array($produtos))
{
    echo '

    <tr>

        <td>'.$linha['id'].'</td>
        <td>'.$linha['nome'].'</td>
        <td>'.$linha['descricao'].'</td>
        <td>'.$linha['id_area'].'</td>
        <td>'.$linha['preco_uni'].'</td>
        <td>'.$linha['moeda'].'</td>
        <td>'.$linha['pais_origem'].'</td>

        <td>
            <img src="'.$linha['imagem'].'" width="100">
        </td>

        <td>
            <a href="editar.php?id='.$linha['id'].'" 
               class="btn btn-warning">
                Editar
            </a>
        </td>

        <td>
            <a href="visualizar.php?id='.$linha['id'].'" 
               class="btn btn-info">
                Visualizar
            </a>
        </td>

    </tr>

    ';

			}

		?>


		

	</table>




	<!-- Paginação fake -->
	<div class="row justify-content-center">
		<nav>
			<ul class="pagination">
				<li class="page-item">
					<a class="page-link" href="#">&laquo;</a>
				</li>

				<li class="page-item active">
					<a class="page-link" href="#">1</a>
				</li>

				<li class="page-item">
					<a class="page-link" href="#">2</a>
				</li>

				<li class="page-item">
					<a class="page-link" href="#">3</a>
				</li>

				<li class="page-item">
					<a class="page-link" href="#">&raquo;</a>
				</li>
			</ul
>		</nav>
	</div>

</div>

</body>
</html>