<?php
	//1) Conexao
	include('../conexao/conexao.php'); 

	//2) Recebendo os valores
	$nome = $_POST['nome'];
	$descricao = $_POST['descricao'];
	$area = $_POST['area'];
	$preco = $_POST['preco'];
	$moeda = $_POST['moeda'];
	$pais = $_POST['pais'];

	// 3) Imagem
	$arqTemp = ['foto']['tmp_name'];
	$arqNome = ['foto']['name'];


?>