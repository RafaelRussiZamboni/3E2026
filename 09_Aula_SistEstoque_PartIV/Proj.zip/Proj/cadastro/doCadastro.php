<?php

// 0) Verificando Session
require('../login/verificador.php');
VerificarLogin();

// 1) Conexao
include('../conexao/conexao.php');

// 2) Recebendo os valores
$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$area = $_POST['area'];
$preco = $_POST['preco'];
$moeda = $_POST['moeda'];
$pais = $_POST['pais'];

// 3) Imagem
$arqTemp = $_FILES['foto']['tmp_name'];
$arqNome = $_FILES['foto']['name'];

// 4) Destino da imagem
$destino = 'C:/wamp64/www/Proj/imagens/' . $arqNome;

// 5) Movendo arquivo para o servidor
if (move_uploaded_file($arqTemp, $destino)) {

    // 6) Query de insert
    $sql = "INSERT INTO produtos(NOME,DESCRICAO,ID_AREA,PRECO_UNI,MOEDA,PAIS_ORIGEM,IMAGEM)VALUES('$nome','$descricao','$area','$preco','$moeda','$pais','$destino')";

    // 7) Executar a Query
    $result = mysqli_query($con, $sql);

    if (!$result) {

        echo "Erro ao cadastrar produto!!!";
        echo "<br>";
        echo mysqli_error($con);

    } else {

        echo "Produto cadastrado com sucesso!";

    }

} else {

    echo "Erro ao salvar o arquivo!!!";
    echo "<br>";
    echo "Caminho: <h4>$destino</h4>";

}
?>