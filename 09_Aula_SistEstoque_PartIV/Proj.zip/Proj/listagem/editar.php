<?php
	//Conexao DB
	include("../conexao/conexao.php");	

	//Verificando session
    require('../login/verificador.php');
    VerificarLogin();

    //Verificando variável da URL ID
    if(!isset($_GET['id']) || empty($_GET['id']))
    {
    	// Se não houver ID, manda de volta!!!
    	header("Location: lista.php");	
    }

    //Recuperando o ID da URL
    $id = $_GET['id'];

    // Buscando os dados atuais do produto
    $query = "SELECT * FROM produtos WHERE id = $id";

    //Executando a query
    $resultado = mysqli_query($con,$query);

    //Recebendo os dados do banco
    $produto = mysqli_fetch_assoc($resultado);

    //Se ID não existir....
    if(!$produto)
    {
    	header("Location: lista.php");
    }

    // Alimentando as variáveis com os dados da coleção
    $nome = $produto['nome'];
    $descricao = $produto['descricao'];
    $area = $produto['id_area'];
    $preco = $produto['preco_uni'];
    $moeda = $produto['moeda'];
    $pais = $produto['pais_origem'];
    $imagem = $produto['imagem'];
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Editar</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container mt-4">

	<!-- Substituindo jumbotron -->
	<div class="p-4 mb-4 bg-light rounded">
		<h1>Edição de Produtos</h1>
		<p>Produtos fofos!</p>
		<p>Bem-vindo: <?php echo $_SESSION['login'] ?></p>
	</div>

	<!-- Navegação -->
	<ul class="nav nav-tabs mb-3">
		<li class="nav-item">
			<a class="nav-link active" href="../Cadastro/cadastro.php">
				Cadastrar Produto
			</a> 
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">
				Lista Produtos
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">
				Usuários
			</a>
		</li>
	</ul>


	<!-- Formulário -->
	<form action="doEditar.php" method="POST" 
		enctype="multipart/form-data">
		<!-- Nome -->
		<div class="mb-3">
			<label class="form-label">Nome:</label>		
			<input type="text" name="nome" class="form-control"
			value="<?php echo $nome ?>">
		</div>
		<!-- Nome -->

		<!-- Descrição -->
		<div class="mb-3">
			<label class="form-label">Descrição:</label>		
			<input type="text" name="descricao" class="form-control" value="<?php echo $descricao ?>">
		</div>
		<!-- Descrição -->

		<!-- Área -->
		<div class="mb-3">
			<label class="form-label">Descrição:</label>		
			<select class="form-select" name="area" id="area">
				<option>...</option>
				<option value="1">Eletrodoméstico</option>
				<option value="2">Eletrônicos</option>
				<option value="3">Manutenção</option>
			</select>
		</div>
		<!-- Área -->

		<!-- Preço -->
		<div class="mb-3">
			<label class="form-label">Preço:</label>		
			<input type="text" name="preco" class="form-control"
			value="<?php echo $preco ?>">
		</div>
		<!-- Preço -->

		<!-- Moeda -->
		<div class="mb-3">
			<label class="form-label">Preço:</label>		
			<select class="form-select" name="moeda" id="moeda">
				<option>...</option>
				<option value="R$">R$ - Real</option>
				<option value="US$">US$ - Dólar</option>
			</select>
		</div>
		<!-- Moeda -->

		<!-- País -->
		<div class="mb-3">
			<label class="form-label">País:</label>		
			<input type="text" name="pais" class="form-control"
			value="<?php echo $pais ?>">
		</div>
		<!-- País -->

		<!-- Imagem -->
		<div class="mb-3">
			<label class="form-label">Imagem:</label>		
			<input type="file" name="foto" class="form-control">
			<small>Apenas se desejar mudar a imagem atual</small>
		</div>
		<!-- Imagem -->		

		<!-- Botões -->
			<div class="d-flex gap-2">
				<button type="submit" class= "btn btn-primary">
				   Salvar Alterações
				</button>

				<a href="lista.php" class= "btn btn-secondary">
					Cancelar	
				</a>	
			</div>
		<!-- Botões -->
	</form>
</div>

<script>
	document.getElementById(area).value = "<?php echo $area ?>";
	document.getElementById(moeda).value = "<?php echo $moeda ?>";
</script>

</body>
</html>